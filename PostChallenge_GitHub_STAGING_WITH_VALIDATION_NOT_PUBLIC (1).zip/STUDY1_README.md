# Study 1 — reproducibility review package (NOT the complete GitHub release)

This package reproduces the saved Study 1 summary statistics using **minimized parsed-choice records**. It is not the complete original raw API response archive. The **combined repository** includes separate Study 2 and Study 3 analysis inputs. It is a private review candidate until public-release approval and final audit.

## Run

Extract this ZIP into a new folder, open a terminal in that folder, then run:

```bash
python reproduce_study1.py
```

Only Python standard-library modules are used; no model API calls occur. The script writes:

- `control_protocol/extension_C_matched_three_model_v1/stage1_analysis/STAGE1_RESULTS_V2.json`
- `control_protocol/extension_C_matched_three_model_v1/stage1_analysis/STAGE1_REPORT_V2.txt`

Compare these files byte-for-byte with matching files under `expected/`.

## Record provenance

- 77 scenarios; the analysis isolates a 70-scenario clean-label sensitivity subset and retains seven ambiguous-role scenarios for other analyses.
- Original GPT initial and follow-up state files were reduced to `status` and `parsed_choice`. One follow-up has `FAILED_FINAL`.
- Original Claude event log contained 6,044 events including Gemini research; we filtered the authoritative Claude Sonnet 4.6 **latest assignment states** (1,232 distinct successful assignments). The public candidate contains only analysis-essential fields, not private provider messages or raw API responses.
- The original analysis source is preserved under `provenance/`, while `reproduce_study1.py` changes only its hard-coded absolute root path to a portable path.

## Limitations

This package checks **analysis reproducibility**, not the complete paper data/code release. The full GitHub package must separately include source raw model responses (or documented release decisions), frozen Study 2/3 inputs and results, scripts, verification of missingness and statistical reporting, and comprehensive credential/privacy review. Do not upload private execution archives or provider configurations as-is.
