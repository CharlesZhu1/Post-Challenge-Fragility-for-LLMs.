#!/usr/bin/env python3

from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import csv
import hashlib
import json
import os

ROOT = Path(
    "/home/charles/sibyl_v2/control_protocol/"
    "extension_C_matched_three_model_v1"
)

S3 = ROOT / "stage3_parent_state_intervention"

RUN = (
    S3 / "runs/STAGE3-SCI-PARENTSTATE-V1"
)

STATE = RUN / "state.json"
ATTEMPTS = RUN / "attempts.jsonl"

ASSIGNMENTS = (
    S3 / "frozen/"
    "STAGE3_DESCENDANT_ASSIGNMENTS_3780_V1.csv"
)

ANALYSIS_SPEC = (
    S3 / "stage3_analysis/"
    "STAGE3_ANALYSIS_SPEC_V1.json"
)

ANALYSIS_SCRIPT = (
    S3 / "stage3_analysis/"
    "run_stage3_analysis_v1.py"
)

ANALYSIS_PREFREEZE = (
    S3 / "stage3_analysis/"
    "STAGE3_ANALYSIS_PREFREEZE_V1.json"
)

OUT = (
    S3 / "frozen/"
    "STAGE3_COLLECTION_FREEZE_V1.json"
)

TERMINAL = {
    "SUCCESS",
    "FAILED_FINAL",
}

FORBIDDEN = {
    "REQUEST_STARTED",
    "RETRY_PLANNED",
    "UNKNOWN_PROVIDER_OUTCOME",
}


def sha256(p):
    return hashlib.sha256(
        p.read_bytes()
    ).hexdigest()


def load_json(p):
    return json.loads(
        p.read_text(encoding="utf-8")
    )


# ============================================================
# Static input validation
# ============================================================

required = [
    STATE,
    ATTEMPTS,
    ASSIGNMENTS,
    ANALYSIS_SPEC,
    ANALYSIS_SCRIPT,
    ANALYSIS_PREFREEZE,
]

for p in required:
    if not p.exists():
        raise SystemExit(
            "STOP: required file missing: "
            + str(p)
        )

with ASSIGNMENTS.open(
    encoding="utf-8-sig",
    newline="",
) as f:
    manifest_rows = list(
        csv.DictReader(f)
    )

if len(manifest_rows) != 3780:
    raise SystemExit(
        f"STOP: expected 3780 manifest rows, "
        f"found {len(manifest_rows)}"
    )

manifest_ids = {
    r["assignment_id"]
    for r in manifest_rows
}

if len(manifest_ids) != 3780:
    raise SystemExit(
        "STOP: duplicate assignment IDs "
        "in frozen manifest."
    )


# ============================================================
# State audit
# ============================================================

state = load_json(STATE)

if state.get("global_halt") is not None:
    raise SystemExit(
        "STOP: global_halt is active: "
        + str(state.get("global_halt"))
    )

assignment_state = state.get(
    "assignments", {}
)

status_counts = Counter(
    r.get("status")
    for r in assignment_state.values()
)

print("=" * 100)
print("STAGE 3 COLLECTION FREEZE AUDIT")
print("=" * 100)

print(
    "provider_calls:",
    state.get("provider_calls"),
)

print(
    "unique assignments touched:",
    len(assignment_state),
)

print(
    "status counts:",
    dict(status_counts),
)

print()

# All manifest assignments must have terminal state.
missing_from_state = sorted(
    manifest_ids
    - set(assignment_state)
)

extra_in_state = sorted(
    set(assignment_state)
    - manifest_ids
)

if missing_from_state:
    print(
        "UNTOUCHED/NONTERMINAL MANIFEST ASSIGNMENTS:",
        len(missing_from_state),
    )

if extra_in_state:
    print(
        "EXTRA STATE ASSIGNMENTS:",
        len(extra_in_state),
    )

for status in sorted(FORBIDDEN):
    ids = [
        aid
        for aid, r in assignment_state.items()
        if r.get("status") == status
    ]

    print(
        f"{status}:",
        len(ids),
    )

    for aid in ids[:20]:
        print(" ", aid)

    if len(ids) > 20:
        print(
            f"  ... plus {len(ids)-20} more"
        )

print()


# ============================================================
# Hard freeze conditions
# ============================================================

problems = []

if len(assignment_state) != 3780:
    problems.append(
        "state does not contain exactly "
        "3780 assignments"
    )

if missing_from_state:
    problems.append(
        f"{len(missing_from_state)} manifest "
        "assignments absent from state"
    )

if extra_in_state:
    problems.append(
        f"{len(extra_in_state)} unexpected "
        "assignments exist in state"
    )

for status in FORBIDDEN:
    n = status_counts.get(status, 0)

    if n:
        problems.append(
            f"{n} assignments remain {status}"
        )

nonterminal_other = [
    aid
    for aid, r in assignment_state.items()
    if r.get("status") not in TERMINAL
]

if nonterminal_other:
    problems.append(
        f"{len(nonterminal_other)} total "
        "nonterminal assignments remain"
    )

terminal_count = sum(
    status_counts.get(x, 0)
    for x in TERMINAL
)

if terminal_count != 3780:
    problems.append(
        f"terminal count is {terminal_count}, "
        "expected 3780"
    )


# ============================================================
# Attempt-log structural checks
# ============================================================

attempt_records = []

with ATTEMPTS.open(
    encoding="utf-8"
) as f:
    for line in f:
        if line.strip():
            attempt_records.append(
                json.loads(line)
            )

attempt_assignment_ids = {
    r.get("assignment_id")
    for r in attempt_records
    if r.get("assignment_id")
}

foreign_attempt_ids = sorted(
    attempt_assignment_ids
    - manifest_ids
)

if foreign_attempt_ids:
    problems.append(
        f"{len(foreign_attempt_ids)} foreign "
        "assignment IDs in attempts log"
    )


# ============================================================
# SUCCESS integrity
# ============================================================

bad_success = []

for aid, r in assignment_state.items():

    if r.get("status") != "SUCCESS":
        continue

    if r.get("parsed_choice") not in {
        "A", "B", "C", "D"
    }:
        bad_success.append(
            (
                aid,
                "invalid parsed_choice",
            )
        )

    if not r.get("response_sha256"):
        bad_success.append(
            (
                aid,
                "missing response_sha256",
            )
        )

if bad_success:
    problems.append(
        f"{len(bad_success)} SUCCESS integrity "
        "problems"
    )


# ============================================================
# FAILED_FINAL provenance
# ============================================================

failed_ids = sorted(
    aid
    for aid, r in assignment_state.items()
    if r.get("status") == "FAILED_FINAL"
)

manual_resolutions = (
    RUN / "manual_resolutions.jsonl"
)

manual_resolution_count = 0

if manual_resolutions.exists():
    with manual_resolutions.open(
        encoding="utf-8"
    ) as f:
        manual_resolution_count = sum(
            1
            for line in f
            if line.strip()
        )


# ============================================================
# Refuse incomplete collection
# ============================================================

if problems:

    print("=" * 100)
    print("COLLECTION FREEZE: NOT READY")
    print("=" * 100)

    for p in problems:
        print(" -", p)

    print()
    print(
        "No collection-freeze file was written."
    )
    print(
        "This is expected while execution "
        "is still incomplete."
    )
    print(
        "NO OUTCOME ANALYSIS PERFORMED."
    )

    raise SystemExit(2)


# ============================================================
# Collection freeze
# ============================================================

freeze = {
    "version":
        "STAGE3_COLLECTION_FREEZE_V1",

    "collection_status":
        "FROZEN",

    "frozen_utc":
        datetime.now(
            timezone.utc
        ).isoformat(),

    "run_id":
        "STAGE3-SCI-PARENTSTATE-V1",

    "planned_assignments":
        3780,

    "terminal_assignments":
        terminal_count,

    "success":
        status_counts.get(
            "SUCCESS", 0
        ),

    "failed_final":
        status_counts.get(
            "FAILED_FINAL", 0
        ),

    "retry_planned":
        status_counts.get(
            "RETRY_PLANNED", 0
        ),

    "request_started":
        status_counts.get(
            "REQUEST_STARTED", 0
        ),

    "unknown_provider_outcome":
        status_counts.get(
            "UNKNOWN_PROVIDER_OUTCOME", 0
        ),

    "provider_calls":
        state.get(
            "provider_calls"
        ),

    "global_halt":
        state.get(
            "global_halt"
        ),

    "failed_final_assignment_ids":
        failed_ids,

    "manual_resolution_records":
        manual_resolution_count,

    "missingness_policy": {
        "failed_final":
            "Missing; no regeneration or imputation.",

        "primary_analysis":
            ">=2 valid SUCCESS replicates per required cell.",

        "strict_sensitivity":
            "3/3 valid SUCCESS replicates per required cell.",
    },

    "files": {
        "state_json": {
            "path": str(STATE),
            "sha256": sha256(STATE),
        },

        "attempts_jsonl": {
            "path": str(ATTEMPTS),
            "sha256": sha256(ATTEMPTS),
        },

        "assignment_manifest": {
            "path": str(ASSIGNMENTS),
            "sha256": sha256(
                ASSIGNMENTS
            ),
        },

        "analysis_spec": {
            "path": str(
                ANALYSIS_SPEC
            ),
            "sha256": sha256(
                ANALYSIS_SPEC
            ),
        },

        "analysis_script": {
            "path": str(
                ANALYSIS_SCRIPT
            ),
            "sha256": sha256(
                ANALYSIS_SCRIPT
            ),
        },

        "analysis_prefreeze": {
            "path": str(
                ANALYSIS_PREFREEZE
            ),
            "sha256": sha256(
                ANALYSIS_PREFREEZE
            ),
        },
    },
}

tmp = OUT.with_suffix(
    OUT.suffix + ".tmp"
)

tmp.write_text(
    json.dumps(
        freeze,
        indent=2,
        sort_keys=True,
    ) + "\n",
    encoding="utf-8",
)

with tmp.open("rb") as f:
    os.fsync(f.fileno())

os.replace(tmp, OUT)

print("=" * 100)
print("COLLECTION FREEZE: PASS")
print("=" * 100)

print(
    "SUCCESS:",
    freeze["success"],
)

print(
    "FAILED_FINAL:",
    freeze["failed_final"],
)

print(
    "provider_calls:",
    freeze["provider_calls"],
)

print(
    "freeze file:",
    OUT,
)

print(
    "freeze SHA256:",
    sha256(OUT),
)

print()
print(
    "Stage 3 collection is now immutable "
    "for analysis."
)
print(
    "Analysis may now be executed."
)
