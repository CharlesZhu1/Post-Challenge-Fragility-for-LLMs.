# Post-Challenge Fragility of LLMs — Analysis Data and Code

**Publication status: STAGING CANDIDATE. Not yet approved for public upload.**

This directory contains the frozen inputs, parsed assignment outcomes and statistical-analysis code used to reproduce the results in *Post-Challenge Fragility of LLMs: A Case Study in Financial Decision Tasks*. It does **not** include the full original raw model API-response envelopes. It does not run any model APIs.

## Quick start

Python 3.10+ (standard library only):

```bash
python reproduce_all.py
```

The command compares the regenerated results with `expected/`. Study 1 and Study 2 use exact JSON equality; the two Study 3 outputs ignore only the generated `created_utc` timestamp. Study 2 and both Study 3 analyses use the saved bootstrap configurations. This can take several minutes; no credentials or API payments are necessary.

## Experiments represented

| Study | Intended | Valid/completed | Analysis input location |
|---|---:|---:|---|
| Study 1: challenge-response | 3,696 | 3,695 | `control_protocol/extension_C_matched_three_model_v1/runs/SCI-MATCHED3-V1/` and `extension_A_crossmodel_v1/` (reduced execution-state records) |
| Study 2: parent-state intervention | 3,780 | 3,775 | `control_protocol/extension_C_matched_three_model_v1/stage3_parent_state_intervention/` |
| Study 3: sequential | 7,132 | 7,128 | `control_protocol/extension_C_matched_three_model_v1/stage4_reversibility_v1/` |
| Study 3: controlled history | 1,260 | 1,260 | `control_protocol/extension_C_matched_three_model_v1/stage4_reversibility_v1/controlled_history_v1/` |

The frozen Study 2 subset contains 70 scenarios. Study 1 uses the 77-scenario benchmark; 70 are clean-label scenarios and seven have ambiguous role labels. See `docs/DATA_SCOPE_AND_LIMITATIONS.md`.

## Repository layout

- `reproduce_all.py` — reproduce and compare all four statistical outputs.
- `reproduce_study1.py` — portable Study 1 analysis.
- `control_protocol/` — saved designs, scenario inventory, decisions, collection, model assignments and analysis programs.
- `expected/` — canonical saved study results.
- `provenance/` — original unmodified analysis scripts and frozen specifications retained for provenance (some original scripts use historical absolute paths and are not the entry points).
- `validation/` — anonymized human-annotation votes, consensus, agreement calculations and reproducible checker.
- `docs/` — data scope, benchmark annotation limitations, prepublication checklist and review findings.
- `FILE_SHA256_MANIFEST.csv` — file integrity reference for this staging package *before rerunning scripts* (some results are overwritten by analysis runs).

## Reproducibility and source-data limitations

The included datasets support rerunning the published statistical analyses. The original provider-response envelopes are not all in this package; only saved parsed outcomes and experiment metadata needed for analysis. A primary-source raw response release would require separately reviewing and sanitizing the original envelopes.

The package now includes **anonymized three-reviewer benchmark choices** and a fully reproducible agreement check for all 77 scenarios (`python validation/verify_benchmark_validation.py`). Fleiss' κ = 0.835760; 65/77 unanimous; 76/77 majority agreements with gold; one three-way disagreement. The historical scenario inventory still carries `not_human_certified` metadata; the later reviewer records do not independently prove annotator credentials or blinding. See `docs/BENCHMARK_VALIDATION.md` and `docs/PUBLICATION_CHECKLIST.md` before releasing.

The original experiments were run using specific frozen model versions: `gpt-4o-mini-2024-07-18`, `gpt-5-mini-2025-08-07`, and `claude-sonnet-4-6`. No claim is made that rerunning live API requests today would yield identical model answers.

No software/data license has been selected for this staging package. Publication requires author approval of the data rights, software terms, and the proposed public scope.
