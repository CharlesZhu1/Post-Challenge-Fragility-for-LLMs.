# Upload procedure (after approval)

1. Review `PUBLICATION_CHECKLIST.md`. Do not upload the current staging zip until its open items have been resolved or consciously addressed in publication documentation.
2. Create a separate empty public GitHub repository; do **not** point `git add` at the original `sibyl_v2` or `findeceptagent` projects.
3. Extract the final **approved** release ZIP into a new directory. Run `python reproduce_all.py` and inspect `git status` before committing.
4. Use GitHub Desktop (Add Existing Repository) or standard git commands in the approved extracted folder to push the approved files.
5. On GitHub, verify `README.md`, 70-scenario selection, datasets and analysis scripts are visible and the reproduction command succeeds from a fresh clone.
6. Put the actual public repository link in the manuscript Data and Code Availability statement, with a clear disclosure of the included parsed records versus any omitted raw API envelopes.

**Do not include:** `.env`, provider configurations with keys, private review ZIPs, whole original machine folders, access tokens, or temporary error logs.
