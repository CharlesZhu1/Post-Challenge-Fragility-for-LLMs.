# Prepublication checklist — manual approvals required

**DO NOT PUBLISH THIS STAGING ZIP UNREVIEWED.** The analyses work from a fresh unpacked directory, but technical reproducibility does not equal ethical/legal publication approval.

- [ ] Confirm the manuscript version, numerical tables and figure values against `expected/` and the specific reported models.
- [ ] Review financial prompts and generated response text for copyright, confidential examples, sensitive content, or unintentional personal information. Confirm all subjects/scenarios are synthetic or authorized for release.
- [x] Reconcile 77 reviewer vote sets against original per-scenario summary and frozen scenario inventory; derive anonymized votes and consensus; reproduce Fleiss' κ 0.835760.
- [ ] Confirm author permission to release anonymized review votes, validate reviewer expertise/independence/blinding, document the single no-majority case and the seven overlapping-role exclusions from Study 2.
- [ ] Agree on scope of raw-response publication: sanitize original provider-response envelopes or explicitly disclose their exclusion and ensure the paper's data/code availability promise is satisfied.
- [ ] Review the 13 historical absolute Linux-home path references and approve retention or prepare reproducibility-preserving alternatives.
- [ ] Manually inspect file content for credentials, provider IDs, secrets, addresses and private information. Automated scans are insufficient; rotate any previously exposed API keys.
- [ ] Choose and add an appropriate LICENSE / data terms / attribution notice after rights review; do not assume all data are freely redistributable.
- [ ] Run `python reproduce_all.py` in a fresh clone after upload, check the repository's file visibility, and verify its README links and GitHub URL.
- [ ] Only then place the actual repository URL in the camera-ready paper.
