# Local screening results (not publication clearance)

- Source: the 53-file combined reproducibility review archive, unpacked independently and tested in a clean directory.
- `python reproduce_all.py` completed with four PASS results and no model API calls.
- Heuristic full-text search of source files flagged **zero** common-format OpenAI/Anthropic, Google, GitHub or AWS tokens, PEM private-key headers or Bearer tokens.
- The same screening found **zero email addresses**, **zero Windows user-profile paths**, and **13** absolute `/home/<user>/` references (mostly historical provenance and frozen file paths).
- The 77-row frozen scenario inventory has **77** `not_human_certified` flags and no nonempty `human_reviewer` values. A separately provided later reviewer ZIP shows 77 labels from each of three annotators; anonymized vote records have now been added and checked against the original per-seed validation summary. Their credentials and independent blinding are not established by the files.
- Raw provider-response envelopes are not all included. Review external release terms and licenses.

This is a **pattern-based scan**, not a comprehensive security, privacy, copyright or data-governance audit. Re-review files before publishing.
